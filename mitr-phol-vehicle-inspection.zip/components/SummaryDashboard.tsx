import React from 'react';
import { InspectionRecord, VehicleType } from '../types';

interface SummaryDashboardProps {
  records: InspectionRecord[];
  onBack: () => void;
}

const SummaryDashboard: React.FC<SummaryDashboardProps> = ({ records, onBack }) => {
  
  // Aggregate data for the "Current Session"
  const total = records.length;
  const passed = records.filter(r => r.overallPassed).length;
  const failed = records.filter(r => !r.overallPassed).length;

  const countByType = (type: VehicleType) => records.filter(r => r.vehicleType === type).length;

  const trailerCount = countByType(VehicleType.SEMI_TRAILER);
  const fullTrailerCount = countByType(VehicleType.FULL_TRAILER);
  const tenWheelCount = countByType(VehicleType.TEN_WHEEL);
  const sixWheelCount = countByType(VehicleType.SIX_WHEEL);
  const smallCarCount = countByType(VehicleType.ETAN) + countByType(VehicleType.OTHER);

  const downloadExcel = () => {
    // CSV Header
    const headers = [
      "Doc ID",
      "Date", 
      "Time", 
      "License Plate", 
      "Vehicle Type", 
      "Owner", 
      "Quota", 
      "Zone",
      "Inspector", 
      "Result", 
      "Remarks (Fail Items)"
    ];

    // CSV Rows
    const rows = records.map(r => [
      r.docNumber,
      r.dateStr,
      new Date(r.timestamp).toLocaleTimeString('th-TH'),
      `"${r.licensePlate}"`, 
      r.vehicleType,
      `"${r.ownerName}"`,
      `"${r.quotaNumber}"`,
      `"${r.zone}"`,
      `"${r.inspectorName}"`,
      r.overallPassed ? "PASS" : "FAIL",
      `"${r.finalRemarks.replace(/"/g, '""')}"` 
    ]);

    const csvContent = "\uFEFF" + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `mitrphol_inspection_report_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center bg-white p-4 rounded-lg shadow-sm">
        <h2 className="text-2xl font-bold text-gray-800">สรุปยอดการตรวจสภาพรถ</h2>
        <div className="flex gap-2">
            <button 
                onClick={downloadExcel} 
                disabled={records.length === 0}
                className={`px-4 py-2 rounded flex items-center gap-2 ${records.length === 0 ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-green-600 text-white hover:bg-green-700'}`}
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Export CSV
            </button>
            <button onClick={onBack} className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300">
                กลับหน้าหลัก
            </button>
        </div>
      </div>

      <div className="bg-white shadow-lg rounded-lg overflow-hidden overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 border-collapse">
          <thead>
            <tr className="bg-blue-50 text-center">
              <th className="p-3 border text-sm font-semibold text-gray-700">ลำดับ</th>
              <th className="p-3 border text-sm font-semibold text-gray-700 min-w-[120px]">ช่วงเวลา</th>
              <th className="p-3 border text-sm font-semibold text-gray-700">จำนวนรถที่ตรวจทั้งหมด (คัน)</th>
              <th className="p-3 border text-sm font-semibold text-white bg-green-600">ผ่าน</th>
              <th className="p-3 border text-sm font-semibold text-white bg-red-600">ไม่ผ่าน</th>
              <th className="p-3 border text-sm font-semibold text-gray-700">รถเทรลเลอร์</th>
              <th className="p-3 border text-sm font-semibold text-gray-700">รถพ่วง</th>
              <th className="p-3 border text-sm font-semibold text-gray-700">10 ล้อ</th>
              <th className="p-3 border text-sm font-semibold text-gray-700">6 ล้อ</th>
              <th className="p-3 border text-sm font-semibold text-gray-700">รถเล็ก</th>
            </tr>
          </thead>
          <tbody className="bg-white text-center">
            {/* Current Session Row Only */}
            <tr className="bg-white font-medium hover:bg-gray-50">
              <td className="p-3 border text-sm text-gray-600">1</td>
              <td className="p-3 border text-sm text-blue-600">วันนี้ (Current Session)</td>
              <td className="p-3 border text-sm text-gray-900 font-bold">{total}</td>
              <td className="p-3 border text-sm bg-green-50 text-green-800 font-bold">{passed}</td>
              <td className="p-3 border text-sm bg-red-50 text-red-800 font-bold">{failed}</td>
              <td className="p-3 border text-sm">{trailerCount}</td>
              <td className="p-3 border text-sm">{fullTrailerCount}</td>
              <td className="p-3 border text-sm">{tenWheelCount}</td>
              <td className="p-3 border text-sm">{sixWheelCount}</td>
              <td className="p-3 border text-sm">{smallCarCount}</td>
            </tr>
          </tbody>
        </table>
      </div>
      
      {/* List of inspections in this session */}
      {records.length > 0 && (
          <div className="bg-white rounded-lg shadow overflow-hidden border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                  <h3 className="text-lg font-bold text-gray-700">รายการรถที่ตรวจวันนี้</h3>
              </div>
              <ul className="divide-y divide-gray-200">
                {records.slice().reverse().map((r, i) => (
                    <li key={r.id} className="p-4 hover:bg-gray-50 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div>
                            <div className="flex items-center gap-2">
                                <span className="font-bold text-gray-900 text-lg">{r.licensePlate}</span>
                                <span className="text-xs px-2 py-1 bg-gray-100 rounded text-gray-600">{r.vehicleType}</span>
                            </div>
                            <p className="text-sm text-gray-500">เจ้าของ: {r.ownerName || '-'} | โควต้า: {r.quotaNumber || '-'}</p>
                            <p className="text-xs text-gray-400 mt-1">{r.dateStr} {new Date(r.timestamp).toLocaleTimeString('th-TH')}</p>
                        </div>
                        <div className="flex items-center gap-4">
                            <span className={`px-3 py-1 rounded-full text-sm font-bold ${r.overallPassed ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                {r.overallPassed ? 'ผ่านเกณฑ์' : 'ไม่ผ่าน'}
                            </span>
                        </div>
                    </li>
                ))}
              </ul>
          </div>
      )}

      {records.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg border-2 border-dashed border-gray-300">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <p className="text-gray-500 text-lg">ยังไม่มีข้อมูลการตรวจในรอบนี้</p>
            <p className="text-gray-400 text-sm">กด "กลับหน้าหลัก" เพื่อเริ่มบันทึกการตรวจ</p>
        </div>
      )}
    </div>
  );
};

export default SummaryDashboard;