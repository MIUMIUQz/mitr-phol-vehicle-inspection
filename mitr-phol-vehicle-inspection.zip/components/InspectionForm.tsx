import React, { useState, useEffect, useRef } from 'react';
import { CHECKLIST_ITEMS } from '../constants';
import { VehicleType, CheckStatus, CheckItemResult, InspectionRecord } from '../types';

// Declare html2canvas and jspdf globally for TypeScript
declare global {
  interface Window {
    html2canvas: any;
    jspdf: any;
  }
}

interface InspectionFormProps {
  onSubmit: (record: InspectionRecord) => void;
  onCancel: () => void;
  sessionStats?: {
      total: number;
      passed: number;
      failed: number;
  };
}

const InspectionForm: React.FC<InspectionFormProps> = ({ onSubmit, onCancel, sessionStats }) => {
  const formRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  // Changed to Array for multiple images
  const [scannedImages, setScannedImages] = useState<string[]>([]);

  // Form Fields
  const [dateStr] = useState(new Date().toLocaleDateString('th-TH', { day: 'numeric', month: 'numeric', year: '2-digit' })); // Format: d/m/yy
  const [vehicleType, setVehicleType] = useState<VehicleType | null>(null);
  const [vehicleTypeOther, setVehicleTypeOther] = useState('');
  const [licensePlate, setLicensePlate] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [quotaNumber, setQuotaNumber] = useState('');
  const [zone, setZone] = useState('');
  const [reInspectDate, setReInspectDate] = useState('');
  
  // Results
  const [results, setResults] = useState<Record<string, CheckItemResult>>({});
  
  // Footer Signatures
  const [inspectorName, setInspectorName] = useState('');
  const [driverName, setDriverName] = useState('');
  const [auditorName, setAuditorName] = useState('');
  const [approverName, setApproverName] = useState('');

  // Initialize
  useEffect(() => {
    const initialResults: Record<string, CheckItemResult> = {};
    CHECKLIST_ITEMS.forEach(item => {
      initialResults[item.id] = { id: item.id, status: null, remark: '' };
    });
    setResults(initialResults);
  }, []);

  const handleStatusChange = (id: string, status: CheckStatus) => {
    setResults(prev => ({ ...prev, [id]: { ...prev[id], status } }));
  };

  const handleRemarkChange = (id: string, remark: string) => {
    setResults(prev => ({ ...prev, [id]: { ...prev[id], remark } }));
  };

  const handleBulkUpdate = (status: CheckStatus) => {
    setResults(prev => {
      const next = { ...prev };
      CHECKLIST_ITEMS.forEach(item => {
        next[item.id] = { ...next[item.id], status: status };
      });
      return next;
    });
  };

  const calculateOverall = (): boolean => {
    const allItems = Object.values(results) as CheckItemResult[];
    // If no items are checked, it's not strictly "fail" yet, but visually we might want to wait. 
    // Assuming if even one is FAIL, overall is FAIL.
    return !allItems.some(r => r.status === CheckStatus.FAIL);
  };

  // --- PDF Generation ---
  const generatePDF = async () => {
    if (!formRef.current || !window.html2canvas || !window.jspdf) return;
    
    setIsSaving(true);
    try {
      const { jsPDF } = window.jspdf;
      // A4 Size in mm: 210 x 297
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();

      const element = formRef.current;
      
      // Preserve original styles
      const originalStyle = element.style.cssText;
      
      // Enforce print dimensions for capture
      element.style.width = '210mm';
      element.style.minHeight = '297mm';
      element.style.height = 'auto';
      element.style.margin = '0';
      element.style.overflow = 'hidden'; 
      
      // Use high scale for clarity
      const canvas = await window.html2canvas(element, { 
        scale: 4, // High resolution (300+ DPI equivalent)
        useCORS: true,
        windowWidth: 1200, // Simulate desktop width for consistent layout
        onclone: (documentClone) => {
            // FIX: Scope selection to the specific form ID
            const clonedForm = documentClone.getElementById('printable-form');
            if (clonedForm) {
                // Sync Inputs (Text, Checkboxes, Radio)
                const originalInputs = element.querySelectorAll('input');
                const clonedInputs = clonedForm.querySelectorAll('input');
                
                originalInputs.forEach((orig, index) => {
                    const clone = clonedInputs[index];
                    if (!clone) return;

                    // Handle Checkboxes/Radios
                    if (orig.type === 'checkbox' || orig.type === 'radio') {
                         if (orig.checked) {
                             clone.setAttribute('checked', 'checked');
                             clone.checked = true;
                         }
                    } 
                    // Handle Text/Number inputs (Skip file inputs)
                    else if (orig.type !== 'file') {
                        clone.value = orig.value;
                        clone.setAttribute('value', orig.value);
                    }
                });

                // Sync Textareas
                const originalTextareas = element.querySelectorAll('textarea');
                const clonedTextareas = clonedForm.querySelectorAll('textarea');
                
                originalTextareas.forEach((orig, index) => {
                    const clone = clonedTextareas[index];
                    if (clone) {
                        clone.value = orig.value;
                        clone.innerHTML = orig.value; // html2canvas often reads innerHTML for textareas
                    }
                });
            }
        }
      });
      
      // Restore styles
      element.style.cssText = originalStyle;

      // Add image to PDF with max quality
      const imgData = canvas.toDataURL('image/jpeg', 1.0); 
      pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`Inspection_${licensePlate || 'Form'}_${new Date().toISOString().slice(0,10)}.pdf`);
    } catch (error) {
      console.error("PDF Gen Error", error);
      alert("เกิดข้อผิดพลาดในการสร้าง PDF");
    } finally {
      setIsSaving(false);
    }
  };

  // --- Scan / OCR Simulation ---
  const handleScanClick = () => {
    if (fileInputRef.current) {
        // Reset value so we can select the same file again if needed (though unlikely)
        fileInputRef.current.value = '';
        fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        setIsScanning(true);
        const reader = new FileReader();
        reader.onload = (event) => {
            const base64 = event.target?.result as string;
            
            // Add new image to the array
            setScannedImages(prev => [...prev, base64]);
            
            // Simulate AI OCR Processing time (Only simulate filling data on the FIRST image upload to avoid overwriting)
            // Or trigger it every time but only if fields are empty? 
            // Let's simple keep the simulation active for "demo" purposes on every upload, 
            // but in real world, maybe only the first page contains the info.
            
            setTimeout(() => {
                // Mock Data Filling (Only if fields are empty to prevent annoyance, or force update)
                // For this demo, we'll update if it's the first image
                if (scannedImages.length === 0) {
                  setLicensePlate("81-9876");
                  setOwnerName("สมชาย มิตรผล");
                  setQuotaNumber("654321");
                  setZone("ตะวันออก");
                  setVehicleType(VehicleType.TEN_WHEEL);
                  handleBulkUpdate(CheckStatus.PASS);
                  setInspectorName("วิชัย ตรวจสอบ");
                  alert("สแกนเสร็จสิ้น: ระบบดึงข้อมูลจากเอกสารแล้ว");
                } else {
                  alert("เพิ่มรูปภาพเรียบร้อย");
                }
                
                setIsScanning(false);
            }, 1000);
        };
        reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = (indexToRemove: number) => {
      if(confirm("ต้องการลบรูปภาพนี้ใช่หรือไม่?")) {
        setScannedImages(prev => prev.filter((_, index) => index !== indexToRemove));
      }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const missingFields = [];
    if (!vehicleType) missingFields.push("ประเภทรถ");
    if (!licensePlate) missingFields.push("ทะเบียนรถ");
    if (!inspectorName) missingFields.push("ชื่อพนักงานผู้ตรวจสอบ");

    if (missingFields.length > 0) {
      alert(`กรุณากรอกข้อมูลให้ครบถ้วน: ${missingFields.join(", ")}`);
      return;
    }

    const record: InspectionRecord = {
      id: Date.now().toString(),
      docNumber: "AC-FM-1100-006/r.01",
      timestamp: Date.now(),
      dateStr,
      vehicleType,
      vehicleTypeOther,
      licensePlate,
      ownerName,
      quotaNumber,
      zone,
      checkResults: Object.values(results),
      overallPassed: calculateOverall(),
      finalRemarks: Object.values(results)
                    .filter(r => r.status === CheckStatus.FAIL && r.remark)
                    .map(r => `ข้อ ${r.id}: ${r.remark}`)
                    .join(', '),
      reInspectDate,
      inspectorName,
      driverName,
      auditorName,
      approverName,
      scannedImages // Pass the array of images
    };

    if(confirm("ยืนยันการบันทึกข้อมูล?")) {
        onSubmit(record);
    }
  };

  // Helper for Checkbox with label
  const CheckBox = ({ checked, label }: { checked: boolean, label: string }) => (
    <div className="flex items-center mr-2">
      <div className={`w-3 h-3 border border-black flex items-center justify-center mr-1 ${checked ? 'bg-black' : 'bg-white'}`}>
        {checked && <svg className="w-2 h-2 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" /></svg>}
      </div>
      <span className="text-[10px] whitespace-nowrap leading-none pt-[1px]">{label}</span>
    </div>
  );

  return (
    <div className="flex flex-col items-center gap-4 relative bg-gray-100 min-h-screen pb-10">
        {/* Loading Overlay */}
        {isScanning && (
            <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex flex-col items-center justify-center text-white">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-white mb-4"></div>
                <h2 className="text-xl font-bold">กำลังประมวลผลรูปภาพ...</h2>
            </div>
        )}

      {/* Control Bar & Session Summary */}
      <div className="w-full max-w-[210mm] space-y-2 print:hidden mt-4">
          {sessionStats && (
              <div className="bg-blue-50 border border-blue-200 p-3 rounded flex justify-between items-center text-sm">
                  <span className="font-bold text-blue-800">📊 สรุปยอดการตรวจวันนี้:</span>
                  <div className="flex gap-4">
                      <span className="text-gray-700">ทั้งหมด: <b>{sessionStats.total}</b></span>
                      <span className="text-green-700">ผ่าน: <b>{sessionStats.passed}</b></span>
                      <span className="text-red-700">ไม่ผ่าน: <b>{sessionStats.failed}</b></span>
                  </div>
              </div>
          )}
          
          <div className="flex flex-wrap gap-2 justify-between bg-white p-4 rounded shadow">
            <button type="button" onClick={onCancel} className="text-gray-600 hover:text-gray-900 px-4 py-2 bg-gray-100 rounded text-sm">
            &larr; ยกเลิก
            </button>
            <div className="flex gap-2">
                <input 
                    type="file" 
                    accept="image/*" 
                    capture="environment" 
                    ref={fileInputRef} 
                    onChange={handleFileChange}
                    className="hidden" 
                />
                <button 
                    type="button" 
                    onClick={handleScanClick}
                    className="flex items-center gap-2 bg-purple-600 text-white px-3 py-2 rounded shadow hover:bg-purple-700 text-sm"
                >
                     📷 {scannedImages.length > 0 ? 'เพิ่มรูปภาพ (Add)' : 'สแกน OCR'}
                </button>
                <button 
                    type="button" 
                    onClick={generatePDF}
                    disabled={isSaving}
                    className="flex items-center gap-2 bg-blue-600 text-white px-3 py-2 rounded shadow hover:bg-blue-700 text-sm"
                >
                    📄 {isSaving ? 'กำลังสร้าง...' : 'Export PDF'}
                </button>
            </div>
          </div>
      </div>

      {/* Scanned Image Preview Gallery */}
      {scannedImages.length > 0 && (
        <div className="w-full max-w-[210mm] p-4 border border-dashed border-gray-400 bg-gray-50 print:hidden">
            <p className="font-bold text-gray-700 mb-2">เอกสารแนบ ({scannedImages.length} หน้า):</p>
            <div className="flex overflow-x-auto gap-4 pb-2">
                {scannedImages.map((img, index) => (
                    <div key={index} className="relative flex-shrink-0 group">
                         <img 
                            src={img} 
                            alt={`Scanned Page ${index + 1}`} 
                            className="h-40 border border-gray-300 shadow-sm object-contain bg-white" 
                        />
                        <button 
                            type="button"
                            onClick={() => handleRemoveImage(index)}
                            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs shadow hover:bg-red-600"
                        >
                            ✕
                        </button>
                        <span className="absolute bottom-0 left-0 bg-black bg-opacity-50 text-white text-[10px] px-1">
                            หน้า {index + 1}
                        </span>
                    </div>
                ))}
                
                {/* Add Button in Gallery */}
                 <div 
                    onClick={handleScanClick}
                    className="h-40 w-28 flex-shrink-0 border-2 border-dashed border-gray-300 bg-gray-100 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-200 text-gray-500"
                >
                    <span className="text-2xl">+</span>
                    <span className="text-xs">เพิ่มรูป</span>
                 </div>
            </div>
        </div>
      )}

      {/* The Paper Form Replica - Strict A4 sizing */}
      <div className="overflow-auto w-full flex justify-center pb-8">
        <div 
            id="printable-form"
            ref={formRef} 
            className="bg-white text-black shadow-2xl relative box-border mx-auto"
            style={{ 
                width: '210mm', 
                minHeight: '297mm',
                padding: '15mm 15mm 10mm 15mm', // Adjust padding
                fontFamily: 'Sarabun, sans-serif',
                fontSize: '10px',
                lineHeight: '1.2'
            }}
        >
            {/* Form Content Wrapper */}
            <div className="flex flex-col h-full justify-between">
                <div>
                    {/* Top Right Code */}
                    <div className="absolute top-4 right-6 text-[10px] font-normal">
                        AC FM 1100 006 / 01
                    </div>
                    
                    {/* Header */}
                    <div className="text-center mb-2 mt-4">
                        <h1 className="font-bold text-[14px]">บริษัท น้ำตาลมิตรผล จำกัด (อำนาจเจริญ)</h1>
                        <h2 className="font-bold text-[12px]">แบบฟอร์มรายงานการตรวจสภาพรถบรรทุกอ้อย</h2>
                    </div>
                    
                    {/* Date */}
                    <div className="flex justify-end mb-1 items-end">
                        <span className="mr-1">วันที่</span>
                        <input 
                            type="text" 
                            value={dateStr} 
                            readOnly
                            className="border-b border-dotted border-black bg-transparent text-center w-[100px] outline-none font-bold"
                        />
                    </div>

                    {/* Vehicle Info Box */}
                    <div className="border border-black p-1.5 mb-1">
                        <div className="flex flex-wrap items-center gap-y-1 mb-1">
                            <span className="mr-2 font-bold">ประเภทรถ:</span>
                            {Object.values(VehicleType).map(type => (
                                <div key={type} onClick={() => setVehicleType(type)} className="cursor-pointer">
                                    <CheckBox checked={vehicleType === type} label={type} />
                                </div>
                            ))}
                            {vehicleType === VehicleType.OTHER && (
                                <input 
                                    type="text" 
                                    className="border-b border-dotted border-black bg-transparent outline-none w-20 ml-1 text-center" 
                                    value={vehicleTypeOther}
                                    onChange={e => setVehicleTypeOther(e.target.value)}
                                />
                            )}
                            <div className="ml-auto flex items-end">
                                <span className="mr-1">รถหมายเลขทะเบียน</span>
                                <input 
                                    type="text" 
                                    value={licensePlate}
                                    onChange={e => setLicensePlate(e.target.value)}
                                    className="border-b border-dotted border-black bg-transparent outline-none w-24 text-center font-bold"
                                />
                            </div>
                        </div>
                        <div className="flex items-end w-full">
                            <span className="whitespace-nowrap mr-1">ชื่อเจ้าของรถบรรทุกอ้อย</span>
                            <input 
                                type="text" 
                                value={ownerName}
                                onChange={e => setOwnerName(e.target.value)}
                                className="border-b border-dotted border-black bg-transparent outline-none flex-grow mr-2"
                            />
                            <span className="whitespace-nowrap mr-1">บรรทุกอ้อยหมายเลขโควต้า</span>
                            <input 
                                type="text" 
                                value={quotaNumber}
                                onChange={e => setQuotaNumber(e.target.value)}
                                className="border-b border-dotted border-black bg-transparent outline-none w-20 mr-2"
                            />
                            <span className="whitespace-nowrap mr-1">เขต</span>
                            <input 
                                type="text" 
                                value={zone}
                                onChange={e => setZone(e.target.value)}
                                className="border-b border-dotted border-black bg-transparent outline-none w-16"
                            />
                        </div>
                    </div>

                    {/* Inspection Table */}
                    <table className="w-full border-collapse border border-black mb-1">
                        <thead>
                            <tr className="bg-gray-200">
                                <th className="border border-black p-1 text-center font-bold" style={{width: '60%'}} rowSpan={2}>รายการตรวจ</th>
                                <th className="border border-black p-0.5 text-center font-bold" colSpan={2} style={{width: '15%'}}>ผลการตรวจ</th>
                                <th className="border border-black p-1 text-center font-bold" style={{width: '25%'}} rowSpan={2}>รายการที่ต้องปรับปรุง</th>
                            </tr>
                            <tr className="bg-gray-200">
                                <th className="border border-black p-0.5 text-center font-bold" style={{width: '7.5%'}}>ผ่าน</th>
                                <th className="border border-black p-0.5 text-center font-bold" style={{width: '7.5%'}}>ไม่ผ่าน</th>
                            </tr>
                        </thead>
                        <tbody>
                            {CHECKLIST_ITEMS.map((item, idx) => (
                                <tr key={item.id} className="h-[22px]"> {/* Fixed row height to control page overflow */}
                                    <td className="border border-black px-1 align-middle text-[10px] leading-tight">
                                        {item.text}
                                    </td>
                                    <td 
                                        className="border border-black p-0 text-center align-middle cursor-pointer hover:bg-green-50"
                                        onClick={() => handleStatusChange(item.id, CheckStatus.PASS)}
                                    >
                                        {results[item.id]?.status === CheckStatus.PASS && (
                                            <span className="text-green-600 font-bold text-sm">✓</span>
                                        )}
                                    </td>
                                    <td 
                                        className="border border-black p-0 text-center align-middle cursor-pointer hover:bg-red-50"
                                        onClick={() => handleStatusChange(item.id, CheckStatus.FAIL)}
                                    >
                                        {results[item.id]?.status === CheckStatus.FAIL && (
                                            <span className="text-red-600 font-bold text-sm">✗</span>
                                        )}
                                    </td>
                                    <td className="border border-black p-0 align-top">
                                        <input
                                            type="text"
                                            className="w-full h-full outline-none bg-transparent px-1 text-[10px]"
                                            value={results[item.id]?.remark}
                                            onChange={e => handleRemarkChange(item.id, e.target.value)}
                                        />
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                <div>
                    {/* Summary Result */}
                    <div className="border border-black p-1 mb-1 flex items-center bg-white">
                        <span className="font-bold mr-2 text-[11px]">ผลการตรวจสภาพ :</span>
                        <div className="flex items-center mr-8 cursor-pointer" onClick={() => {/* Auto-calculated by logic, not manual check */}}>
                            <div className={`w-4 h-4 border border-black mr-2 flex items-center justify-center ${calculateOverall() ? 'bg-black' : 'bg-white'}`}>
                                {calculateOverall() && <span className="text-white text-xs">✓</span>}
                            </div>
                            <span className="text-[11px]">ผ่าน (ได้รับการติดสติ๊กเกอร์)</span>
                        </div>
                        <div className="flex items-center cursor-pointer">
                            <div className={`w-4 h-4 border border-black mr-2 flex items-center justify-center ${!calculateOverall() ? 'bg-black' : 'bg-white'}`}>
                                {!calculateOverall() && <span className="text-white text-xs">✓</span>}
                            </div>
                            <span className="text-[11px]">ไม่ผ่านต้องทำการปรับปรุงแก้ไข</span>
                        </div>
                    </div>

                    {/* Notes */}
                    <div className="text-[9px] mb-2 space-y-0.5 leading-tight">
                        <div className="flex">
                            <span className="mr-1 font-bold">หมายเหตุ:</span>
                            <div className="w-full">
                                <p>1. ให้แนบรูปถ่ายรถด้านหน้าทุกคัน ที่ทำการตรวจสอบ (ให้เห็นหมายเลขทะเบียนรถ)</p>
                                <p>2. รถบรรทุกที่จะได้รับการติดสติ๊กเกอร์ ผลการตรวจสภาพรถจะต้อง <span className="underline font-bold">ผ่าน</span> ทุกข้อกำหนด</p>
                                <div className="flex items-center flex-wrap">
                                    <span>3. รถบรรทุกที่ผลการตรวจสภาพรถ <span className="underline font-bold">ไม่ผ่าน</span> เจ้าของรถจะทำการปรับปรุงแก้ไข และพร้อมให้ตรวจ วันที่</span>
                                    <input
                                        type="text"
                                        value={reInspectDate}
                                        onChange={e => setReInspectDate(e.target.value)}
                                        className="border-b border-dotted border-black w-24 text-center outline-none bg-transparent mx-1 h-4"
                                    />
                                    <span>...........................................................................................</span>
                                </div>
                                <p>4. <span className="underline font-bold">ห้ามไม่ให้นำเด็กโดยสารมากับรถในการขนส่งอ้อยเข้ามาในพื้นที่โรงงาน</span></p>
                            </div>
                        </div>
                    </div>

                    {/* Signatures */}
                    <div className="grid grid-cols-2 gap-x-8 gap-y-3 mt-1 mb-2">
                        {/* Inspector */}
                        <div className="text-center">
                            <div className="flex items-end justify-center gap-1 mb-0.5">
                                <span>ลงชื่อ</span>
                                <input 
                                    type="text" 
                                    value={inspectorName} 
                                    onChange={e => setInspectorName(e.target.value)}
                                    className="border-b border-dotted border-black w-32 text-center outline-none bg-transparent" 
                                />
                                <span>พนักงานผู้ตรวจสอบ</span>
                            </div>
                            <div className="flex items-center justify-center gap-1">
                                <span>(</span>
                                <input 
                                    type="text" 
                                    value={inspectorName} 
                                    readOnly
                                    className="border-b border-dotted border-black w-32 text-center bg-transparent outline-none" 
                                />
                                <span>)</span>
                            </div>
                        </div>

                        {/* Driver */}
                        <div className="text-center">
                            <div className="flex items-end justify-center gap-1 mb-0.5">
                                <span>ลงชื่อ</span>
                                <input 
                                    type="text" 
                                    value={driverName} 
                                    onChange={e => setDriverName(e.target.value)}
                                    className="border-b border-dotted border-black w-32 text-center outline-none bg-transparent" 
                                />
                                <span>เจ้าของรถบรรทุก</span>
                            </div>
                            <div className="flex items-center justify-center gap-1">
                                <span>(</span>
                                <input 
                                    type="text" 
                                    value={driverName} 
                                    readOnly
                                    className="border-b border-dotted border-black w-32 text-center bg-transparent outline-none" 
                                />
                                <span>)</span>
                            </div>
                        </div>

                        {/* Auditor */}
                         <div className="text-center">
                            <div className="flex items-end justify-center gap-1 mb-0.5">
                                <span>ลงชื่อ</span>
                                <input 
                                    type="text" 
                                    value={auditorName} 
                                    onChange={e => setAuditorName(e.target.value)}
                                    className="border-b border-dotted border-black w-32 text-center outline-none bg-transparent" 
                                />
                                <span>ผู้ตรวจสอบ</span>
                            </div>
                            <div className="text-[9px] mt-0">หัวหน้าเขตส่งเสริม</div>
                        </div>

                        {/* Approver */}
                        <div className="text-center">
                            <div className="flex items-end justify-center gap-1 mb-0.5">
                                <span>ลงชื่อ</span>
                                <input 
                                    type="text" 
                                    value={approverName} 
                                    onChange={e => setApproverName(e.target.value)}
                                    className="border-b border-dotted border-black w-32 text-center outline-none bg-transparent" 
                                />
                                <span>ผู้อนุมัติ</span>
                            </div>
                            <div className="text-[9px] mt-0">วิศวกร/หัวหน้าแผนก</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>

       {/* Submit Action Bar */}
       <div className="w-full max-w-[210mm] mt-2 mb-8 print:hidden">
            <div className="flex gap-2">
                 <button 
                  type="button" 
                  onClick={() => handleBulkUpdate(CheckStatus.PASS)}
                  className="flex-1 py-3 bg-green-100 text-green-800 font-bold rounded shadow hover:bg-green-200"
                >
                  ✓ ผ่านทั้งหมด
                </button>
                 <button 
                  type="button" 
                  onClick={() => handleBulkUpdate(CheckStatus.FAIL)}
                  className="flex-1 py-3 bg-red-100 text-red-800 font-bold rounded shadow hover:bg-red-200"
                >
                  ✗ ไม่ผ่านทั้งหมด
                </button>
            </div>
           <button
            onClick={handleSubmit}
            className="w-full py-4 bg-blue-900 text-white font-bold rounded shadow-lg hover:bg-blue-800 text-lg mt-2"
           >
               บันทึกผลการตรวจ (Save Record)
           </button>
       </div>
    </div>
  );
};

export default InspectionForm;